public class MyName{
  public static void main(String[] args){
    System.out.println("Mi nombre es Coding Dojo\nTengo 100 años de edad.\nMi ciudad es Burbank, CA");
  }
}

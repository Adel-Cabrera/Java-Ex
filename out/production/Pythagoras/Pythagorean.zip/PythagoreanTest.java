public class PythagoreanTest {
    public static void main(String[] args){
        Pythagorean py = new Pythagorean();
        System.out.println(py.calculateHypotenuse(5, 4));
    }
}

public class FizzbuzzTest {
    public static void main(String[] args){
        Fizzbuzz fiz = new Fizzbuzz();
        System.out.println(fiz.fizzBuzz(15));
    }
}
